# Swiggy Instamart — SnapCheck 2.0: Zero-Effort Verification

**AI proactively detects order issues and alerts users only when it matters.**

## The Problem
Users rarely verify grocery orders against what was actually delivered — they only notice missing or wrong items after unpacking. Raising an issue after the fact takes time and effort, which drives dependency on support and increases frustration.

## The Solution
An AI risk engine that cross-checks order, warehouse pack, and delivery scan data to predict missing- or wrong-item risk **before** the user even opens the bag — then sends a proactive alert only when risk is high or medium.

**How it works:**
Order placed → AI cross-checks item/qty/category across data sources → risk scoring → order delivered → smart alert *only if needed* → user reviews flagged issues → one-tap resolution (instant refund, replace item, contact support, or view order details)

## Why It Works
- **Zero user effort** — no manual verification of every order
- **Proactive** — issues are flagged before the user notices them
- **Builds trust without adding friction** — the system works in the background and only surfaces when it actually matters

## MVP Scope
**In scope:** top 20 high-frequency grocery categories, order/warehouse/delivery scan integration, risk engine for missing & wrong items, proactive alert with one-tap resolution
**Out of scope (v1):** photo scan by user, expiry/quality checks, complex substitutions, in-store experience

## Success Metrics
% of issues detected proactively · support tickets per 1K orders · refund turnaround time · repeat order rate & NPS uplift

## Projected Impact
**70%** faster issue detection · **40%** reduction in support tickets · higher user trust and NPS · increase in repeat orders
