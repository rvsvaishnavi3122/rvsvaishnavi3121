# Weather Mode — Ride Optimization for Rapido Link

*UX case study: Rapido vs. Uber*

## Problem
Users drop off during bad weather because of unpredictable surge pricing. Demand-supply analysis showed riders were bearing the cost of uncertainty, not just the cost of the surge itself.

## Insight
Users value **certainty over price** in high-intent scenarios. When weather makes trip completion urgent, the willingness to pay a known price is higher than the willingness to gamble on a fluctuating one.

## Solution
Introduced **Weather Mode**, a dedicated flow with three options:
- **Quick Ride** — fastest available match
- **Save & Wait** — lower cost, longer wait
- **Assured Ride** — guaranteed confirmation, with SMS driver notification so the ride is confirmed even under poor network conditions

**User flow:** Open app → Weather Mode → Select option → Confirm → Driver notified via app + SMS → Ride confirmed

## Impact
- Wait times cut from **2–3 hrs to under 15 min**
- **+35%** booking completion
- **+20%** conversion, **-15%** drop-offs, **+25%** fulfillment

## Conclusion
Designing for predictability — not just lower prices — improves trust and retention during peak demand.
